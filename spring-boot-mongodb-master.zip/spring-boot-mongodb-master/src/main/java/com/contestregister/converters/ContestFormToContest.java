package com.contestregister.converters;

import org.bson.types.ObjectId;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.contestregister.commands.ContestForm;
import com.contestregister.domain.Contest;

/**
 * Created by jt on 1/10/17.
 */
@Component
public class ContestFormToContest implements Converter<ContestForm, Contest> {

    @Override
    public Contest convert(ContestForm contestForm) {
        Contest contest = new Contest();
        if (contestForm.getId() != null  && !StringUtils.isEmpty(contestForm.getId())) {
            contest.setId(new ObjectId(contestForm.getId()));
        }
        contest.setDescription(contestForm.getDescription());
        contest.setPrice(contestForm.getPrice());
        contest.setImageUrl(contestForm.getImageUrl());
        return contest;
    }
}
