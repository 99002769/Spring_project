package com.contestregister.converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.contestregister.commands.ContestForm;
import com.contestregister.domain.Contest;

/**
 * Created by jt on 1/10/17.
 */
@Component
public class ContestToContestForm implements Converter<Contest, ContestForm> {
    @Override
    public ContestForm convert(Contest contest) {
        ContestForm contestForm = new ContestForm();
        contestForm.setId(contest.getId().toHexString());
        contestForm.setDescription(contest.getDescription());
        contestForm.setPrice(contest.getPrice());
        contestForm.setImageUrl(contest.getImageUrl());
        return contestForm;
    }
}
