package com.contestregister.repositories;

import org.springframework.data.repository.CrudRepository;

import com.contestregister.domain.Contest;

/**
 * Created by jt on 1/10/17.
 */
public interface ContestRepository extends CrudRepository<Contest, String> {
}
